import React from 'react';
import { Link } from '@reach/router';

export const Home = (props) => {
    const {className} = props;
    return (
        <>
            <div className={className}>
                <Link to="/all/users">Show Users</Link>
            </div>
        </>
    );
};