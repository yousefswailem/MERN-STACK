import React, {useEffect, useState} from 'react';
import { Link } from '@reach/router';
import axios from 'axios';
import { Card } from './basics/card';
import { UserForm } from './userForm';

export const Users = (props) => {
    const {className} = props;
    const [allUsers, setAllUsers] = useState([]);

    useEffect(
        () => {
            axios.get("http://localhost:8000/api/users")
            .then(res => {
                setAllUsers(res.data.users);
            })
        }, [allUsers]
    );

    return (
        <>
            <Link to="/">Home</Link>
            <UserForm className="card" />
            <div className={className}>
                {
                    allUsers.map( (user) =>
                        <Card className="box" userinfo={user} key={user._id} />
                    )
                }
            </div>
        </>
    );
};