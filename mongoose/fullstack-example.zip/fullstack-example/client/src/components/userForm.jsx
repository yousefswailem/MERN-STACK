import React, { useState } from  'react';
import axios from 'axios';

export const UserForm = (props) => {
    const [username, setUsername] = useState("");
    const [usernameErr, setUsernameErr] = useState("");
    const [age, setAge] = useState("");
    const [ageErr, setAgeErr] = useState("");
    const [submitErr, setSubmitErr] = useState("");
    
    const usernameErrMesgs = {
        empty: "Username cannot be empty",
        minLength: "Username have to be 3 char or more"
    };

    const ageErrMesgs = {
        empty: "Age cannot be empty",
        minAge: "You are too young! 13+ only."
    };

    const submitErrMesgs = {
        noSubmit: "Please fix the errors above before submitting the form"
    };
    
    const createUser = (e) => {
        e.preventDefault();
        if(validateUsername(username) && validateAge(age)){
            const newUser = {name: username, age: age};
            axios.post('http://localhost:8000/api/users/new', newUser)
            .then(res=> {
                setUsername("");
                setAge("");
                setSubmitErr("");
            })
            .catch(err => {
                const errStr =  err.response.data.error.errors.age.message + ", " 
                + err.response.data.error.errors.name.message;
                setSubmitErr(errStr);
            })
        } else {
            setSubmitErr(submitErrMesgs.noSubmit);
        }
    };

    const validateUsername = (value) => {
        setUsername(value);
        if(value.length < 1) {
            setUsernameErr(usernameErrMesgs.empty);
            return false;
        } else if (value.length < 3) {
            setUsernameErr(usernameErrMesgs.minLength);
            return false;
        } else {
            setUsernameErr("");
            return true;
        }
    };

    const validateAge = (value) => {
        setAge(value); 
        if(value.length < 1) {
            setAgeErr(ageErrMesgs.empty);
            return false;
        } else if (!isNaN(value) && parseInt(value) < 13) {
            setAgeErr(ageErrMesgs.minAge);
            return false;
        } else {
            setAgeErr("");
            return true;
        }
    };
    
    return(
        <form onSubmit={ createUser } className={props.className}>
            <div>
                <input placeholder="User Name" type="text" onChange={ (e) => validateUsername(e.target.value)} value={username} />
                {
                    usernameErr && 
                    <p style={{color: 'red'}}>{usernameErr}</p>
                }
            </div>
            <div>
                <input placeholder="Age" type="number" onChange={ (e) => validateAge(e.target.value) } value={age}/>
                {
                    ageErr && 
                    <p style={{color: 'red'}}>{ageErr}</p>
                }
            </div>
            <input type="submit" value="Create User" />
            {
                submitErr && 
                <p style={{color: 'red'}}>{submitErr}</p>
            }
        </form>
    );
};