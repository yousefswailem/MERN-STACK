import axios from 'axios';
import React from 'react';

export const Card = (props) => {
    const {className, userinfo} = props;

    const deleteUser = (e) => {
        axios.delete("http://localhost:8000/api/users/delete/" + userinfo._id)
        .then(res => console.log("-I- " + res))
        .catch(err => console.log("-E- " + err))
    }

    return (
        <div className={className}>
            <p>{"Name: " + userinfo.name}</p>
            <p>{"Age: " + userinfo.age}</p>
            <button onClick={deleteUser}>delete</button>
        </div>
    );
};