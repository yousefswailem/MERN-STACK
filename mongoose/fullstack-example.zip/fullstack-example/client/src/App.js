import './App.css';
import { Router } from '@reach/router';
import { Users } from './components/users';
import { Home } from './components/home';

function App() {
  return (
    <div className="flexBox">
      <Router>
        <Users path="/all/users" className="flexBox"/>
        <Home path="/" className="flexBox"/>
      </Router>
    </div>
  );
}

export default App;
